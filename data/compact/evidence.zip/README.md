# Evidence archive

Companion to “Runtime Assurance and the Limits of Alignment Evidence in Embodied Agents”.

This compact archive preserves the completed study's derived numerical evidence,
frozen analysis source and fifteen protocol files, and separately marked proposed
reporting code. These files are byte-identical to the prior completed-study package.
It excludes raw camera/depth archives and the third-party simulator binary.
No public deposit or unrestricted reuse licence is implied.

From the extracted directory, using Python 3.10 or later:

    python3 review-data/verify_reported_results.py
    python3 -m unittest discover -s proposed-code -v

The first verifies accounting, the three primary-group contrasts, six focused
contrasts, unchanged original sensitivity comparisons, preservation of all originally
complete outcomes, arm totals and derivative hashes from previously scored labels.
It does not recreate labels from raw physics or images. Only the physical contrast
was prespecified as primary; the other two are exploratory.
The second runs eleven synthetic software tests, not scientific experiments.
The proposed code has no simulator connection or control authority.

Full raw-data reanalysis requires the sealed raw archives and original dependencies;
see frozen-analysis/README.md and Supplementary Information. Frozen precollection
status labels and inherited generic settings are retained verbatim. The disclosed
corrected scorer and integrated-study specification define the reported analysis.
SHA256SUMS.json records every other file in this archive.
