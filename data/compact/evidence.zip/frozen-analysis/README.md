# Frozen analysis source

The source files, corrected endpoint scorer, fixed study plan and fifteen protocol files preserve the original bytes used by the completed study. `original-bytes-sha256.json` lists their hashes. This directory is separate from the new `proposed-code/` reporting demonstration.

`scorer.py` is the disclosed corrected scorer with SHA-256 `aaa4087d0c32d844dbfb74aca9f7813d762ce27cfdd821ecd6ff0793b85ff62c`. Its correction concerns verdict-label case in analysis, not flight behavior. The plan retains the originally frozen scorer binding; the prior authenticated reproduction explicitly bound this erratum rather than silently changing the plan.

Precollection labels such as `frozen_specification_unrun` describe the files at freeze time. They are intentionally unchanged. Inherited generic analysis options do not replace the integrated study's planned bounded contrasts. The manuscript and Online Resource 1 document the final outcomes, missing records and deviations.

These sources permit inspection of the endpoint and runtime definitions. Full execution requires the retained raw archives and dependencies of the original research environment. The compact review-data arithmetic script needs only Python's standard library and the included derived labels. No simulator or cloud execution is needed for that check.
